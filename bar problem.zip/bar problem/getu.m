function [u]=getu(BC,NN,uf,ND,NDOF)
ue=zeros(ND,1);
for i = 1:ND
    ig = (BC(i,1)-1)*NDOF + BC(i,2);
    UBCDoF=ig;
    ue(ig,1) = BC(i,3);
end
FBCDoF=setdiff((1:NN),UBCDoF);
u(UBCDoF,1)=ue;
u(FBCDoF,1)=uf;

end