function [KG]=formK(NEN,NDOF,NN,ELECON,CORD,lm,NE,le,A,E)
%%This will be generating global stiffness matrix
%initialize
KG=zeros(NN*NDOF);
NEE=NDOF*NEN;    %total dof in an element
for i=1:NE
    [Ke]=formKe(A,E,le,i); %to get the elemental stiff mat corres to ith element
    for j=1:NEE
        jg=lm(i,j);
        for l=1:NEE
            lg=lm(i,l);
            KG(jg,lg)=KG(jg,lg)+Ke(j,l);
        end
    end
end
end
            

