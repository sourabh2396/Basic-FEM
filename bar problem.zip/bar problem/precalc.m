function [le,E,A]= precalc(NE,CORD,MAT,SEC)
%This function calculate and stores elemental length,Youngs modulus and
%area
le=zeros(NE,1);
E=zeros(NE,1);
A=zeros(NE,1);
for i=1:NE
    le(i,1)=CORD(i+1,1)-CORD(i,1);
    E(i,1)=MAT(i,1);
    A(i,1)=SEC(i,1);
end
end