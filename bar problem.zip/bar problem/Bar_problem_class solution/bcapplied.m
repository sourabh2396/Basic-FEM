function[Fg1,Kg1]=bcapplied(ND,BC,NDOF,NN,Fg,Kg)
Kg1=Kg;
Fg1=Fg;
TDOF=NDOF*NN;
for i=1:ND
    bcnode=BC(i,1);
    bcdof=NDOF*(bcnode-1)+BC(i,2);
    for k=1:TDOF
        Fg1(k)=Fg(k)-BC(i,3)*Kg(k,bcdof);
    end
    Kg1(bcdof,:)=0;
    Kg1(:,bcdof)=0;
    Kg1(bcdof,bcdof)=1;
    Fg1(bcdof)=BC(i,3);
end
end