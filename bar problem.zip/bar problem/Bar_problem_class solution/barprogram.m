clear all;
clc;
finp=fopen('assigninput.txt','r'); % 'file name','permission'
[NN,NE,NM,NP,NIP,NDIM,NEN,NDOF,ND,NL,NEUDL,NRC,CORD,ELECON...
,BC,PLOAD,UDL,MAT,SEC]=assignscan(finp);
% Calculation of DOF matrix -[lm]
[lm]=dofmat(NE,NEN,NDOF,ELECON);
% Global Stiffness matrix
[KG]=formK(NEN,NDOF,NN,ELECON,CORD,SEC,MAT,lm,NE);
% Global load vector
[FG]=formF(NEN,NDOF,NN,CORD,lm,UDL,NEUDL,ELECON,NL,PLOAD);
% Application of boundary conditions
[Fg1,Kg1] = bcapplied(ND,BC,NDOF,NN,FG,KG);
% Solving for displacements
u = linsolve(Kg1,Fg1)
% Reactions 
R = KG*u-FG