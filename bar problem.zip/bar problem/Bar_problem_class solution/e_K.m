function [KE]=e_K(ELECON,CORD,SEC,MAT,i)
   N1=ELECON(i,1);   % 1st node for i^th element
   N2=ELECON(i,2);   % 2nd node for i^th element
   x1=CORD(N1,1);    % defined cordinate according to nodes of i^th element
   x2=CORD(N2,1);
   a(i)=x2-x1;       % length of i^th element
   secn=ELECON(i,5); % section no
   A=SEC(secn,1);    % area of i^th element
   matn=ELECON(i,4); % material no.
   E=MAT(matn,1);    % young's modulus of i^th element

%  Element stiffness matrix  
   KE=(E*A/a(i))*[1 -1;-1 1];
end