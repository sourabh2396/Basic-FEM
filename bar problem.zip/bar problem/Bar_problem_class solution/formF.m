function [FG]=formF(NEN,NDOF,NN,CORD,lm,UDL,NEUDL,ELECON,NL,PLOAD)
% Generation of element load vector and its assembled counterparts
NEE=NEN*NDOF;
FG=zeros(NDOF*NN,1);  % have defined size of global force matrix and its all element are zero.
FE=zeros(1,NEN*NDOF);
st=1;
for ii=1:NEUDL                                     
  % Calculating Element level stiffness matrix
   i=UDL(ii,1);
   N1=ELECON(i,1);   % 1st node for i^th element
   N2=ELECON(i,2);   % 2nd node for i^th element
   x1=CORD(N1,1);    % defined cordinate according to nodes of i^th element
   x2=CORD(N2,1);
   a=x2-x1;       % length of i^th element
   q=UDL(st,2);
   FE=0.5*q*a*[1;1]; % for constant udl                                                                           % Force vector
   st=st+1; 
   
   [FG]=assemF(FE,NEE,lm,i,FG);  % Assembly to Global Matrix
end
% Point loads
[FG]=loads_at_node(NDOF,NL,FG,PLOAD);
end