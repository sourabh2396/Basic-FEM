function [lm]=dofmat(NE,NEN,NDOF,ELECON)
%%This will store global DOF no for local DOF of each element
for i=1:NE
    for j=1:NEN
        NODEN=ELECON(i,j);
        for k=1:NDOF
            l=(j-1)*NDOF+k;   %local DOF no
            lm(i,j)=(NODEN-1)*NDOF+k;
        end
    end
end
end