function [Ke]=formKe(A,E,le,i)
%For calculating elemental stiffness for ith element.
    Ke=A(i,1)*E(i,1)/le(i,1)*[1 -1;-1 1];
end