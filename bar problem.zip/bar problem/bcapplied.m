function [Fg1,Kg1] = bcapplied(ND,BC,NDOF,NN,FG,KG)
Kg1=zeros(NN*NDOF-ND);
Fg1=zeros(NN*NDOF-ND,1);
%for k=1:ND
for i=1:NN*NDOF-ND
    Fg1(i,1)=FG(i+1,1);
    for j=1:NN*NDOF-ND
        Kg1(i,j)=KG(i+1,j+1);
        dummy=sum(BC(:,3));
        Fg1(i,1)=FG(i+1,1)-((KG(i+1,j)*dummy));
    end
end

end