close all;
clear all;
clc;
finp=fopen('input_lab3.txt','r'); % 'file name','permission'
[NN,NE,NM,NP,NIP,NDIM,NEN,NDOF,ND,NL,NEUDL,NRC,CORD,ELECON...
,BC,PLOAD,UDL,MAT,SEC]=assignscan(finp);
UDL
%precalculation for elemental area,length and E
[le,E,A]= precalc(NE,CORD,MAT,SEC);
% Calculation of DOF matrix -[lm]
[lm]=dofmat(NE,NEN,NDOF,ELECON);
% Global Stiffness matrix
[KG]=formK(NEN,NDOF,NN,ELECON,CORD,lm,NE,le,A,E);
% Global load vector
[FG]=formF(NEN,NDOF,NN,CORD,lm,UDL,NEUDL,ELECON,NL,PLOAD,NE,le);
% Application of boundary conditions
[Fg1,Kg1] = bcapplied(ND,BC,NDOF,NN,FG,KG);
% Solving for displacements
uf = linsolve(Kg1,Fg1);
%displacements at global nodes
[u]=getu(BC,NN,uf,ND,NDOF);
% Reactions
R = KG*u-FG;


%For output
fout=fopen('Solutions_Lab3','wt');
fprintf(fout,'Global stiffness matrix=');
fprintf(fout,'\n');
for i=1:size(KG)
    for j=1:size(KG)
        fprintf(fout,'%f',KG(i,j));
        fprintf(fout,'\t');
    end
    fprintf(fout,'\n');
end
fprintf(fout,'\n');
fprintf(fout,'Global Load vector=');
fprintf(fout,'\n');
for k=1:size(FG)
    fprintf(fout,'%f',FG(k));
    fprintf(fout,'\n');
end
fprintf(fout,'\n');

fprintf(fout,'Application of Boundary cnditions:=');
fprintf(fout,'\n');
fprintf(fout,'Redused Stiffness matrix:=');
fprintf(fout,'\n');

for l=1:size(Kg1)
    for m=1:size(Kg1)
        fprintf(fout,'%f',Kg1(l,m));
        fprintf(fout,'\t');
    end
     fprintf(fout,'\n');
end
    
  
fprintf(fout,'\n');
fprintf(fout,'Redused load vector:=');
fprintf(fout,'\n');

for l=1:size(Fg1)    
fprintf(fout,'%f',Fg1(l));
fprintf(fout,'\n');
end
fprintf(fout,'\n');
fprintf(fout,'Displacement at nodes:=');
fprintf(fout,'\n');

for l=1:size(u)    
fprintf(fout,'%f',u(l));
fprintf(fout,'\n');
end

fprintf(fout,'\n');
fprintf(fout,'Reactions=');
fprintf(fout,'\n');

for l=1:size(R)    
fprintf(fout,'%f',R(l));
fprintf(fout,'\n');
end