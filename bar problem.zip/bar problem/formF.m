function [FG]=formF(NEN,NDOF,NN,CORD,lm,UDL,NEUDL,ELECON,NL,PLOAD,NE,le)
%%This will be generating global stiffness matrix
%initialize
FG=zeros(NN*NDOF,1);
NEE=NDOF*NEN;
%Elemental bodyforce matrix
Fe=zeros(NEN,1);
for i=1:NEUDL
    iel=UDL(i,1)
    b=UDL(i,2);
    Fe=0.5*b*le(iel)*[1;1]
    for j=1:NEE
        jg=lm(iel,j);
        FG(jg)=FG(jg)+Fe(j)
    end
end
%Application of point load
for i = 1:NL
    ig = (PLOAD(i,1)-1)*NDOF + PLOAD(i,2);
    FG(ig,1) = PLOAD(i,3);
end
end