function [FG]=formF(NEN,NDOF,NN,CORD,lm,UDL,NEUDL,ELECON,NL,PLOAD,TMAT,NETRAC,SEC,NIP,MAT)
%%  Generation of body Force  vector and its assembled counterparts
NEE=NEN*NDOF;
FG=zeros(NDOF*NN,1);  % have defined size of global force matrix and its all element are zero.
st=1;
%UDL
for ii=1:NEUDL
    i=UDL(ii,1);   %Element
    matn=ELECON(i,5);
    rho=MAT(matn,3);
    %    b=[bx;by];
    for j=1:NEN
        for k=1:NDOF
            Xn(j,k)=CORD(ELECON(i,j),k);  %to get the coordinates of ith element
        end
    end
    [W,gpzi,gpeta]=gauss_quad(NIP); %to get weights and gauss points
    
    FE=zeros(NEN*NDOF,1);
    for a=1:NIP
        for b=1:NIP
            N=[1/4*(1-gpzi(a))*(1-gpeta(b)),0,1/4*(1+gpzi(a))*(1-gpeta(b)),0,1/4*(1+gpzi(a))*(1+gpeta(b)),0,1/4*(1-gpzi(a))*(1+gpeta(b)) 0;
                0 1/4*(1-gpzi(a))*(1-gpeta(b)),0,1/4*(1+gpzi(a))*(1-gpeta(b)),0,1/4*(1+gpzi(a))*(1+gpeta(b)),0,1/4*(1-gpzi(a))*(1+gpeta(b))];
            Bzi=1/4*[gpeta(b)-1,1-gpeta(b) ,1+gpeta(b),-(1+gpeta(b));gpzi(a)-1,-(1+gpzi(a)),(1+gpzi(a)),(1-gpzi(a))];
            J=Bzi*Xn;
            det(J)
            r=N(1,1)*Xn(1,1)+N(1,3)*Xn(2,1)+N(1,5)*Xn(3,1)+N(1,7)*Xn(4,1);%interpolating for r
            bx=0;
            by=-(rho*9.81);
            body_force=[bx;by];
            FE=FE+2*pi*W(a)*W(b)*transpose(N)*body_force*det(J)*r% Force vector
            st=st+1;
        end
    end
    [FG]=assemF(FE,NEE,lm,i,FG) % Assembly to Global Matrix
end
%% Traction
for p=1:NETRAC
    q=TMAT(p,1); %Element
    local_edge=TMAT(p,2);  %LOCALEDGE
    tx1=TMAT(p,3);
    tx2=TMAT(p,4);
    for j=1:NEN
        for k=1:NDOF
            Xn(j,k)=CORD(ELECON(q,j),k);  %to get the coordinates of ith element
        end
    end
     % to get weights and gauss points
   
    [W,gpzi,gpeta]=gauss_quad(NIP);
    if local_edge==1
        gpzi(1)=1;
           gpzi(2)=1;
    elseif local_edge==2
        gpeta(1)=-1;
        gpeta(2)=-1;
    elseif local_edge==3
        gpzi(1)=-1;
        gpzi(2)=-1;
    elseif local_edge==4
        gpeta(1)=1;
        gpeta(2)=1;
    end
    FT=0;
    t=[0;0;0;0;tx1;0;tx2;0];
     for a=1:NIP
        for b=1:NIP
            N=[1/4*(1-gpzi(a))*(1-gpeta(b)),0,1/4*(1+gpzi(a))*(1-gpeta(b)),0,1/4*(1+gpzi(a))*(1+gpeta(b)),0,1/4*(1-gpzi(a))*(1+gpeta(b)) 0;
                0 1/4*(1-gpzi(a))*(1-gpeta(b)),0,1/4*(1+gpzi(a))*(1-gpeta(b)),0,1/4*(1+gpzi(a))*(1+gpeta(b)),0,1/4*(1-gpzi(a))*(1+gpeta(b))];
             Bzi=1/4*[gpeta(b)-1,1-gpeta(b) ,1+gpeta(b),-(1+gpeta(b));gpzi(a)-1,-(1+gpzi(a)),(1+gpzi(a)),(1-gpzi(a))];
            J=Bzi*Xn;
            r=N(1,1)*Xn(1,1)+N(1,3)*Xn(2,1)+N(1,5)*Xn(3,1)+N(1,7)*Xn(4,1);%interpolating for r
             FT=FT+2*pi*W(a)*W(b)*transpose(N)*N*t*r*det(J);  % Force vector
        end
    end
    %we need to use two point integration in 1D
    st=st+1;
    [FG]=assemF(FT,NEE,lm,q,FG)
end

% Point loads
[FG]=loads_at_node(NDOF,NL,FG,PLOAD);
end