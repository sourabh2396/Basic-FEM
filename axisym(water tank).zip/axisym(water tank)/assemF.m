function [F]=assemF(FE,NEE,lm,i,F)
for j=1:NEE                           
    jg=lm(i,j);    
    F(jg,1)=F(jg,1)+FE(j);   
end
end