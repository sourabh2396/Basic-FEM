function [KG]=assemK(KE,NEE,lm,i,KG)

for j=1:NEE        % It selects Jth row of element level stiffness matrix.                  
for k=1:NEE        % It selects Kth columne of the element level stiffness matrix.
    jg=lm(i,j);    % for above selected element corresponding row in global matrix. 
    kg=lm(i,k);    % for above selected element corresponding column in global matrix.
    KG(jg,kg)=KG(jg,kg)+KE(j,k);        % Global stiffness matrix
end
end

end