clear all;
clc;
finp=fopen('input.txt','r'); % 'file name','permission'
[NN,NE,NM,NP,NIP,NDIM,NEN,NDOF,ND,NL,NEUDL,NRC,NETRAC,CORD,ELECON,BC,PLOAD,UDL,TMAT,MAT,SEC]=assignscan(finp);
%%  Calculation of DOF matrix -[lm]
[lm]=dofmat(NE,NEN,NDOF,ELECON);
%%  Global Stiffness matrix
[KG]=formK(NEN,NDOF,NN,ELECON,CORD,SEC,MAT,lm,NE,NIP)
%%  Global load vector
[FG]=formF(NEN,NDOF,NN,CORD,lm,UDL,NEUDL,ELECON,NL,PLOAD,TMAT,NETRAC,SEC,NIP,MAT)
%%  Application of boundary conditions
[Fg1,Kg1,ue,FBCDoF,UBCDoF] = bcapplied(ND,BC,NDOF,NN,FG,KG);% Solving for displacements
u(FBCDoF,1) = linsolve(Kg1,Fg1);
u(UBCDoF,1)=ue;
%%  Reactions 
R = KG*u-FG;
% %generate output file
% [output]=getoutput(u,R);