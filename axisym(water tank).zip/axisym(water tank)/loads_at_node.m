function [FG]=loads_at_node(NDOF,NL,FG,PLOAD)
for i=1:NL
    
    loadnode=PLOAD(i,1);                                  % node at which load is defined
    loaddof=NDOF*(loadnode-1)+PLOAD(i,2);
    FG(loaddof)=FG(loaddof)+PLOAD(i,3) ;               % Adding nodal point loads in force matrix
 
    
end