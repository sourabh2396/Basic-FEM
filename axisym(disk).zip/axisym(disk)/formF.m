function [FG]=formF(NEN,NDOF,NN,CORD,lm,UDL,NEUDL,ELECON,NL,PLOAD,TMAT,NETRAC,SEC,NIP,MAT)
% Generation of element load vector and its assembled counterparts
NEE=NEN*NDOF;
FG=zeros(NDOF*NN,1);  % have defined size of global force matrix and its all element are zero.
st=1;
%UDL
for ii=1:NEUDL                                     
   i=UDL(ii,1);   %Element number
   matn=ELECON(i,5);
   rho=MAT(matn,3)
   w=2*pi*UDL(ii,2)/60;  %radian per second
%    by=UDL(ii,3);  %y compoenent
%    b=[bx;by];
   for j=1:NEN
        for k=1:NDOF
            Xn(j,k)=CORD(ELECON(i,j),k) ;%to get the coordinates of ith element
        end
    end
    [W,gpzi,gpeta]=gauss_quad(NIP); %to get weights and gauss points 
  
    FE=0;
    for a=1:NIP
        for b=1:NIP
            N=[1/4*(1-gpzi(a))*(1-gpeta(b))  0 1/4*(1+gpzi(a))*(1-gpeta(b)) 0 1/4*(1+gpzi(a))*(1+gpeta(b)) 0 1/4*(1-gpzi(a))*(1+gpeta(b)) 0;
                 0 1/4*(1-gpzi(a))*(1-gpeta(b)) 0 1/4*(1+gpzi(a))*(1-gpeta(b)) 0 1/4*(1+gpzi(a))*(1+gpeta(b)) 0 1/4*(1-gpzi(a))*(1+gpeta(b))];
            Bzi=1/4*[gpeta(b)-1 1-gpeta(b)  1+gpeta(b)  -(1+gpeta(b)) ;gpzi(a)-1 -(1+gpzi(a)) (1+gpzi(a)) (1-gpzi(a))];
            J=Bzi*Xn;      
            r=N(1,1)*Xn(1,1)+N(1,3)*Xn(2,1)+N(1,5)*Xn(3,1)+N(1,7)*Xn(4,1); %interpolating for r
            body_force=rho*r*w^2;   %centrifugal force per unit volume
            FE=FE+2*pi*W(a)*W(b)*transpose(N)*body_force*det(J)*r^2;   % Force vector
            st=st+1;    
 
        end
    end
    FE
     [FG]=assemF(FE,NEE,lm,i,FG);  % Assembly to Global Matrix
end
%Traction
for p=1:NETRAC
    q=TMAT(p,1); %Element
    s=TMAT(p,2);  %LOCALEDGE
    t=TMAT(p,3);   %traction value
    if s==1
        gpzi=1;
        gpeta=0;
    elseif s==2
        gpeta=-1;
        gpzi=0;
    elseif s==3
        gpzi=-1;
        gpeta=0;
    elseif s==4
        gpeta=1;
        gpzi=0;
    end
    for j=1:NEN
        for k=1:NDOF
            Xn(j,k)=CORD(ELECON(q,j),k);  %to get the coordinates of ith element
        end
    end
  FT=0;
  W=2;
            N=[1/4*(1-gpzi)*(1-gpeta)  0 1/4*(1+gpzi)*(1-gpeta) 0 1/4*(1+gpzi)*(1+gpeta) 0 1/4*(1-gpzi)*(1+gpeta) 0;
                 0 1/4*(1-gpzi)*(1-gpeta) 0 1/4*(1+gpzi)*(1-gpeta) 0 1/4*(1+gpzi)*(1+gpeta) 0 1/4*(1-gpzi)*(1+gpeta)];
            Bzi=1/4*[gpeta-1 1-gpeta  1+gpeta  -(1+gpeta) ;(gpzi-1) -(1+gpzi) (1+gpzi) (1-gpzi)];
            J=Bzi*Xn;      
            r=N(1,1)*Xn(1,1)+N(1,3)*Xn(2,1)+N(1,5)*Xn(3,1)+N(1,7)*Xn(4,1); %interpolating for r
            FT=FT+2*pi*W*transpose(N)*r*s;    % Force vector
            st=st+1;    
    
%     tx=t*cos;
%     ty=t*sin; 
    [FG]=assemF(FT,NEE,lm,q,FG);
end
    
% Point loads
[FG]=loads_at_node(NDOF,NL,FG,PLOAD);
end