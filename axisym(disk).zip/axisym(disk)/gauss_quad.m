function [W,gpzi,gpeta]=gauss_quad(NIP)
if NIP==1
    W=2;
    gpzi=0; gpeta=0;
elseif NIP==2
    W1=1.0000000000000000;
    W2=1.0000000000000000;
    zi1=-1/sqrt(3);
    zi2=1/sqrt(3);
    eta1=-1/sqrt(3);
    eta2=1/sqrt(3);
    W=[W1 W2]; gpzi=[zi1 zi2]; gpeta=[eta1 eta2];
% elseif NIP==3
% we can enter values for multiple guass points as well
    
end
end