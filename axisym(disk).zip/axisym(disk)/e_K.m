function [KE]=e_K(ELECON,CORD,SEC,MAT,i,NIP,NEN,NDOF)
   matn=ELECON(i,5); % material no
   E=MAT(matn,1);    % young's modulus of i^th element
   mu=MAT(matn,2);    %Poissons ratio of ith element
   D=E/((1+mu)*(1-2*mu))*[1-mu mu mu 0;mu 1-mu mu 0;mu mu (1-mu) 0;0 0 0 0.5*(1-2*mu)]
    for j=1:NEN
        for k=1:NDOF
            Xn(j,k)=CORD(ELECON(i,j),k);  %to get the coordinates of ith element
        end
    end
    [W,gpzi,gpeta]=gauss_quad(NIP);
    %calculating Bzi at gauss points
    KE=0;
    for a=1:NIP
        for b=1:NIP
             N=[1/4*(1-gpzi(a))*(1-gpeta(b)) 1/4*(1+gpzi(a))*(1-gpeta(b)) 1/4*(1+gpzi(a))*(1+gpeta(b)) 1/4*(1-gpzi(a))*(1+gpeta(b))];
            Bzi=1/4*[gpeta(b)-1 1-gpeta(b) 1+gpeta(b) -(1+gpeta(b));gpzi(a)-1 -(1+gpzi(a)) (1+gpzi(a)) (1-gpzi(a))];
            J=Bzi*Xn
            A=inv(J)*Bzi;
            r=N(1)*Xn(1,1)+N(2)*Xn(2,1)+N(3)*Xn(3,1)+N(4)*Xn(4,1);%interpolating for r
            B=[A(1,1) 0 A(1,2) 0 A(1,3) 0 A(1,4) 0;
        0 A(2,1) 0 A(2,2) 0 A(2,3) 0 A(2,4);
        N(1,1)/r 0 N(1,2)/r 0 N(1,3)/r 0 N(1,4)/r 0;
        A(2,1) A(1,1) A(2,2) A(1,2) A(2,3) A(1,3) A(2,4) A(1,4)] 
    %  Element stiffness matrix  
    KE=KE+2*pi*W(a)*W(b)*transpose(B)*D*B*r*det(J);
        end
    end
  
end