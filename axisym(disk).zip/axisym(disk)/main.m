clear all;
clc;
finp=fopen('input.txt','r'); % 'file name','permission'
[NN,NE,NM,NP,NIP,NDIM,NEN,NDOF,ND,NL,NEUDL,NRC,NETRAC,CORD,ELECON,BC,PLOAD,UDL,TMAT,MAT,SEC]=assignscan(finp)
%%  Calculation of DOF matrix -[lm]
[lm]=dofmat(NE,NEN,NDOF,ELECON);
%%  Global Stiffness matrix
[KG]=formK(NEN,NDOF,NN,ELECON,CORD,SEC,MAT,lm,NE,NIP)
%%  Global load vector
[FG]=formF(NEN,NDOF,NN,CORD,lm,UDL,NEUDL,ELECON,NL,PLOAD,TMAT,NETRAC,SEC,NIP,MAT)
%%  Application of boundary conditions
[Fg1,Kg1,ue,FBCDoF,UBCDoF] = bcapplied(ND,BC,NDOF,NN,FG,KG);% Solving for displacements
u(FBCDoF,1)= linsolve(Kg1,Fg1);
u(UBCDoF,1)=ue;
% Reactions 
 R = KG*u-FG;
%% Postprocessing
[sigma_corner]=getstress(u,MAT,2,ELECON,NIP,lm,NEN,NDOF,CORD)
sigma_r_analy=(3+mu)/8*rho*omega^2*r_disk^2*(1-(r^2/r_disk^2));
sigma_theta_analy=(3+mu)/8*rho*omega^2*r_disk^2*(1-((1+3*mu)/(3+mu))*(r^2/r_disk^2));