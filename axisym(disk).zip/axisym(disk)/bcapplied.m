function [Fg1,Kg1,ue,FBCDoF,UBCDoF] = bcapplied(ND,BC,NDOF,NN,FG,KG)
ue=zeros(ND,1);
UBCDoF = zeros(ND,1);
for i = 1:ND
    ig = (BC(i,1)-1)*NDOF + BC(i,2);
    UBCDoF(i)=ig;
    ue(i,1) = BC(i,3);
end
FBCDoF=setdiff((1:NN*NDOF),UBCDoF);
Kg1=zeros(NN*NDOF-ND);
Fg1=zeros(NN*NDOF-ND,1);
for i = 1:1:NN*NDOF-ND
    for j = 1:1:NN*NDOF-ND
        ig = FBCDoF(1,i);
        jg = FBCDoF(1,j);
        Kg1(i,j) = KG(ig,jg);
        Fg1(i,1) = FG(ig,1);
    end
end