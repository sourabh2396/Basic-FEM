    function [KG]=formK(NEN,NDOF,NN,ELECON,CORD,SEC,MAT,lm,NE,NIP)

% Generation of element matrix and its assembled counterparts
NEE=NEN*NDOF ;        % size of the stiffness matrix
KG=zeros(NDOF*NN);    % have defined size of global Stiffness matrix and its all elements are zero
for i=1:NE                                      
  [KE]=e_K(ELECON,CORD,SEC,MAT,i,NIP,NEN,NDOF); % Calculating Element level stiffness matrix
  [KG]=assemK(KE,NEE,lm,i,KG);
end

end