function [Ke_gp,fe_gp]=formKeFe_gq(Nzi,Bzi,E,I,le,NIP,W,gp,NE,UDL,zi)
for i=1:NE
    qzi=((UDL(i,2)-UDL(i,1))/(2))*(zi+1)+(UDL(i,1));
    f=(transpose(Bzi))*E(i,1)*I(i,1)*Bzi*(le(i,1)/2);
    g=transpose(Nzi)*qzi*le(i,1)/2;
    Ke_gp=0;
    fe_gp=0;
    for j=1:NIP
        Ke_gp=Ke_gp+W(j)*subs(f,gp(j));
        fe_gp=fe_gp+W(j)*subs(g,gp(j));
    end
end
end
