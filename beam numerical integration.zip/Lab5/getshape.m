function [Nx,Bx,Nzi,Bzi]=getshape(x,zi,NE,le)
for i=1:NE
    a=le(NE,1);
    N1x=1-3*(x^2/a^2)+2*(x^3/a^3);
    N2x=x-2*(x^2/a)+(x^3/a^2);
    N3x=3*(x^2/a^2)-2*(x^3/a^3);
    N4x=(x^3/a^2)-(x^2/a);
    Nx=[N1x,N2x,N3x,N4x];
    Bx=diff(Nx,x,2);
    N1zi=1/4*(1-zi)^2*(2+zi);
    N2zi=1/8*(1-zi)^2*(1+zi);
    N3zi=1/4*(1+zi)^2*(2-zi);
    N4zi=1/8*(1+zi)^2*(-1+zi);
    Nzi=[N1zi N2zi N3zi N4zi];
    Bzi=(4/le(i)^2)*diff(Nzi,zi,2);
end
end
    