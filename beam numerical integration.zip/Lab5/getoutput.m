function [output]=getoutput(Ke,Fe,Ke_gp,fe_gp)
output=fopen('Solutions_Lab5','wt');
fprintf(output,'Element stiffness matrix by closed form');
fprintf(output,'\n');
fprintf(output,'\n');
for i=1:size(Ke,1)
    for j=1:size(Ke,2)
        fprintf(output,'%f',Ke(i,j));
        fprintf(output,'\t');     
    end
    fprintf(output,'\n');
    
end
fprintf(output,'\n');
fprintf(output,'Element force vector by closed form');
fprintf(output,'\n');
fprintf(output,'\n');
for i=1:size(Fe,1)
        fprintf(output,'%f',Fe(i));
        fprintf(output,'\n');
end
fprintf(output,'\n');
fprintf(output,'Element stiffness matrix by Numerical Integration');
fprintf(output,'\n');
fprintf(output,'\n');
for i=1:size(Ke_gp,1)
    for j=1:size(Ke_gp,2)
        fprintf(output,'%f',Ke_gp(i,j));
        fprintf(output,'\t');     
    end
    fprintf(output,'\n');
    
end
fprintf(output,'\n');
fprintf(output,'Element force vector by Numerical Integration');
fprintf(output,'\n');
fprintf(output,'\n');
for i=1:size(fe_gp,1)
        fprintf(output,'%f',fe_gp(i));
        fprintf(output,'\n');
end