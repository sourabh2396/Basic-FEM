function [Fe]=formf_closed(N,x,le,NE,UDL,CORD)
for i=1:NE
    q=((UDL(i,2)-UDL(i,1))/((CORD(i+1,1)-CORD(i,1))))*(x-CORD(i,1))+(UDL(i,1));
    f=transpose(N)*q;
    Fe=int(f,0,le(i,1));
end
end
    