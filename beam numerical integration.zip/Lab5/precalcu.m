function [le,E,A,I]=precalcu(NE,CORD,ELECON,MAT,SEC);
le=zeros(NE,1);
E=zeros(NE,1);
A=zeros(NE,1);
I=zeros(NE,1);

for i=1:NE
 le(i)=CORD(i+1,1)-CORD(i,1);
 E(i)=MAT(ELECON(i,3),1);
 A(i)=SEC(ELECON(i,4),1);
 I(i)=SEC(ELECON(i,4),2);
end
end