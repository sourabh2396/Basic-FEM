close all;
clear all;
clc;
finp=fopen('input_lab5.txt','r'); % 'file name','permission'
[NN,NE,NM,NP,NIP,NDIM,NEN,NDOF,ND,NL,NEUDL,NRC,CORD,ELECON...
,BC,PLOAD,UDL,MAT,SEC]=assignscan(finp);
syms x zi;
%prcalculation
[le,E,A,I]=precalcu(NE,CORD,ELECON,MAT,SEC);
%shape functions defination
[Nx,Bx,Nzi,Bzi]=getshape(x,zi,NE,le);
%elemental stiffness by using closed integration
[Ke]=formKe_closed(Bx,I,E,le,x,NE);
%Load vector generation using closed integration
[Fe]=formf_closed(Nx,x,le,NE,UDL,CORD);
%Reading weights and gauss poits
[W,gp]=gauss_quad(NIP);
%For Numerical integration with gauss quadrature
[Ke_gp,fe_gp]=formKeFe_gq(Nzi,Bzi,E,I,le,NIP,W,gp,NE,UDL,zi);

%%For output

[output]=getoutput(Ke,Fe,Ke_gp,fe_gp);
