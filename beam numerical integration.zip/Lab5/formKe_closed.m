function [Ke]=formKe_closed(Bx,I,E,le,x,NE)
for i=1:NE
    f=transpose(Bx)*E(i,1)*I(i,1)*Bx;
    Ke=int(f,0,le(i,1));
end
end
