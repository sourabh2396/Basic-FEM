function [KE]=e_K(ELECON,CORD,SEC,MAT,i)
   N1=ELECON(i,1);   % 1st node for i^th element
   N2=ELECON(i,2);  % 2nd node for i^th element
   N3=ELECON(i,3);
   x1=CORD(N1,1);    % defined cordinate according to nodes of i^th element
   y1=CORD(N1,2);
   x2=CORD(N2,1);
   y2=CORD(N2,2);
   x3=CORD(N3,1);
   y3=CORD(N3,2);
   temp=[x1 y1 1;
       x2 y2 1;
       x3 y3 1];
   t=SEC(1);
   A=0.5*det(temp);   %Area of element
   matn=ELECON(i,4);  % material no.
   E=MAT(matn,1) ;   % young's modulus of i^th element
   mu=MAT(matn,2);    %poissons ratio
   D=E/(1-mu^2)*[1 mu 0;mu 1 0;0 0 0.5*(1-mu)];          %stiffness matrix
   B=[(y2-y3)/(2*A) 0 (y3-y1)/(2*A) 0 (y1-y2)/(2*A) 0;   %strain displacement matrix
       0 (x3-x2)/(2*A) 0 (x1-x3)/(2*A) 0 (x2-x1)/(2*A);
       (x3-x2)/(2*A) (y2-y3)/(2*A) (x1-x3)/(2*A) (y3-y1)/(2*A) (x2-x1)/(2*A) (y1-y2)/(2*A)];
%  Element stiffness matrix  
    KE=A*transpose(B)*D*B*t;
end