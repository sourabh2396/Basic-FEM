function [lm]=dofmat(NE,NEN,NDOF,ELECON)
for i=1:NE
    for j=1:NEN
        noden=ELECON(i,j);
        for k=1:NDOF
            lm(i,(j-1)*NDOF+k)=NDOF*(noden-1)+k;
        end
    end
end
end