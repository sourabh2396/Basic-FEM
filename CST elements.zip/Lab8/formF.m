function [FG]=formF(NEN,NDOF,NN,CORD,lm,UDL,NEUDL,ELECON,NL,PLOAD,TMAT,NETRAC,SEC)
% Generation of element load vector and its assembled counterparts
NEE=NEN*NDOF;
FG=zeros(NDOF*NN,1);  % have defined size of global force matrix and its all element are zero.
FT=zeros(1,NEN*NDOF); %defined size of traction force matrix
st=1;
%UDL
for ii=1:NEUDL                                     
   i=UDL(ii,1);
   bx=UDL(ii,2);  %x component
   by=UDL(ii,3);  %y compoenent
   N1=ELECON(i,1);%nodal coordinates
   N2=ELECON(i,2);
   N3=ELECON(i,3);
   x1=CORD(N1,1); % defined cordinate according to nodes of i^th element
   y1=CORD(N1,2);
   x2=CORD(N2,1);
   y2=CORD(N2,2);
   x3=CORD(N3,1);
   y3=CORD(N3,2);
   temp=[x1 y1 1;
       x2 y2 1;
       x3 y3 1];
   A=0.5*det(temp);   %Area of element     
   FE=A/3*[bx;by;bx;by;bx;by];                                                                       % Force vector
   st=st+1; 
   
   [FG]=assemF(FE,NEE,lm,i,FG);  % Assembly to Global Matrix
end
%Traction
for p=1:NETRAC
    q=TMAT(p,1); %Element
    r=TMAT(p,2);  %LOCALEDGE
    for xx=1:2
        ednode(xx)=ELECON(q,r-1+xx);   %NODES CORRES TO LOCAL EDGE
        edlocalnode(xx)=r-1+xx;        %LOCAL NODES
        ednodedof(2*xx-1)=(edlocalnode(xx)-1)*NDOF+1;  %TO FIND DOF NO
        ednodedof(2*xx)=(edlocalnode(xx)-1)*NDOF+2;
    end
    t=TMAT(p,3)*SEC(1); %converting stress into traction
    x1=CORD(ednode(1),1);  %define coordinate acc to node of rth element
    y1=CORD(ednode(1),2);
    x2=CORD(ednode(2),1);
    y2=CORD(ednode(2),2);
    le=sqrt((y2-y1)^2+(x2-x1)^2);
    sin=(x1-x2)/le;      %calculating angles to find out components
    cos=(y2-y1)/le;
    tx=t*cos;
    ty=t*sin; 
    for xx=1:2
        FT(ednodedof(2*xx-1),1)=le*tx/2;
        FT(ednodedof(2*xx),1)=le*ty/2;
    end
    [FG]=assemF(FT,NEE,lm,q,FG);
end
    
% Point loads
[FG]=loads_at_node(NDOF,NL,FG,PLOAD);
end