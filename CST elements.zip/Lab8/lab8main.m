clear all;
clc;
format shortE
finp=fopen('assigninput.txt','r'); % 'file name','permission'
%finp=fopen('assigninput2.txt','r');  %  For part b
[NN,NE,NM,NP,NIP,NDIM,NEN,NDOF,ND,NL,NEUDL,NRC,NETRAC,CORD,ELECON,BC,PLOAD,UDL,TMAT,MAT,SEC]=assignscan(finp);
% Calculation of DOF matrix -[lm]
[lm]=dofmat(NE,NEN,NDOF,ELECON);
% Global Stiffness matrix
[KG]=formK(NEN,NDOF,NN,ELECON,CORD,SEC,MAT,lm,NE);
% Global load vector
[FG]=formF(NEN,NDOF,NN,CORD,lm,UDL,NEUDL,ELECON,NL,PLOAD,TMAT,NETRAC,SEC);
% Application of boundary conditions
[Fg1,Kg1] = bcapplied(ND,BC,NDOF,NN,FG,KG);
% Solving for displacements
u =linsolve(Kg1,Fg1)
% Reactions 
R = KG*u-FG
%Output
output=getoutput(u,R);