function [output]=getoutput(u,R)
output=fopen('Solutions_Lab8','wt');
fprintf(output,'\n');
fprintf(output,'Displacement at nodes:=');
fprintf(output,'\n');

for i=1:size(u)    
fprintf(output,'%f',u(i));
fprintf(output,'\n');
end

fprintf(output,'\n');
fprintf(output,'Reactions=');
fprintf(output,'\n');

for j=1:size(R)    
fprintf(output,'%f',R(j));
fprintf(output,'\n');
end
end