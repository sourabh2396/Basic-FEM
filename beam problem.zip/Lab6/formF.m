function [FG]=formF(NEN,NDOF,NN,CORD,lm,load,NEUDL,ELECON,NL,PLOAD,NE,le,W,gp,H)
%%This will be generating global stiffness matrix
%initialize
FG=zeros(NN*NDOF,1);
NEE=NDOF*NEN;
%Elemental bodyforce matrix
for i=1:NE
    temp=load(i)*transpose(H);
    Fe=le(i)/2*(W(1)*subs(temp,gp(1))+W(2)*subs(temp,gp(2))+W(3)*subs(temp,gp(3)));
    for j=1:NEE
        jg=lm(i,j);
        FG(jg)=FG(jg)+Fe(j);
    end
end
%Application of point load
for i = 1:NL
    ig = (PLOAD(i,1)-1)*NDOF + PLOAD(i,2);
    FG(ig,1) = PLOAD(i,3);
end
end