function [Ke]=formKe(E,le,i,I,B,W,gp)
temp=transpose(B)*E*I(i)*B;
Ke=le(i)/2*(W(1)*subs(temp,gp(1))+W(2)*subs(temp,gp(2))+W(3)*subs(temp,gp(3)));
end