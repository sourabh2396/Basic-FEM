function [H,B]=getshape(zi,NE,le)
H=[1/4*(1-zi)^2*(2+zi),le(1)/8*(1-zi)^2*(1+zi),1/4*(1+zi)^2*(2-zi),le(1)/8*(1+zi)^2*(zi-1)];
B=4/le(1)^2*diff(H,zi,2);
end
