close all;
clear all;
clc;
finp=fopen('input_Lab6(16).txt','r'); % 'file name','permission'
[NN,NE,NM,NP,NIP,NDIM,NEN,NDOF,ND,NL,NEUDL,NRC,CORD,ELECON...
,BC,PLOAD,UDL,MAT,SEC]=assignscan(finp);
syms zi;
%precalculation for elemental area,length and E and direction cosines
[le,E,I,load]= precalc(NE,CORD,MAT,SEC,ELECON,zi,UDL);
%shape functions
[H,B]=getshape(zi,NE,le);
% Calculation of DOF matrix -[lm]
[lm]=dofmat(NE,NEN,NDOF,ELECON);
%Gauss qudarature
[W,gp]=gauss_quad(NIP);
% Global Stiffness matrix
 [KG]=formK(NEN,NDOF,NN,ELECON,CORD,lm,NE,le,E,I,B,W,gp);
% Global load vector
 [FG]=formF(NEN,NDOF,NN,CORD,lm,load,NEUDL,ELECON,NL,PLOAD,NE,le,W,gp,H);
% Application of boundary conditions
[Fg1,Kg1,ue,FBCDoF,UBCDoF] = bcapplied(ND,BC,NDOF,NN,FG,KG);
% Solving for displacements
uf = linsolve(Kg1,Fg1);
%solution at global nodes
[u]=getu(NN,NDOF,FBCDoF,UBCDoF,uf,ue);
%maximum stress at A
kappa=B*u(1:4);
strainA=-(30e-3*kappa);
temp=E*strainA;
stress=subs(temp,-1);
%For output
[output]=getoutput(KG,FG,u,stress);

% For ploting(The data has been given in the Data for plotting.txt file)
nel=[1 2 4 6];
wa=[-0.003299 -0.003326 -0.003326 -0.003329];
thetaa=[-0.005143 -0.005047 -0.005046 -0.005049];
sigmaa=[57040998.217469 53588136.142390 52439197.487021 52247801.141863];
thetab=[0.001235 0.001102 0.001059 0.001056]; 
sigmab=[14814814.814815 16494316.114814 15786697.014473 15623737.316985];
subplot(3,1,1)
plot(nel,wa,'o');
xlabel('no of elements');
ylabel('deflection at B(canti)');
subplot(3,1,2)
plot(nel,thetaa,'s');
xlabel('No of elements');
ylabel('rotation at B(canti)');
subplot(3,1,3)
plot(nel,sigmaa,'o');
xlabel('no of elements');
ylabel('max stress at A canti');figure;
subplot(2,1,1)
plot(nel,thetab,'s');
xlabel('No of elements');
ylabel('rotation at B(fixedpoint)');
subplot(2,1,2)
plot(nel,sigmaa,'o');
xlabel('no of elements');
ylabel('max stress at A fixedpoint');
