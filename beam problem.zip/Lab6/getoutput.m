function [output]=getoutput(KG,FG,u,stress)
output=fopen('Solutions_Lab6','wt');
fprintf(output,'\n');
fprintf(output,'Global stiffness matrix=');
fprintf(output,'\n');
for i=1:size(KG,1)
    for j=1:size(KG,2)
        fprintf(output,'%f',KG(i,j));
        fprintf(output,'\t');
        fprintf(output,'\t');
        
    end
    fprintf(output,'\n');
end
fprintf(output,'\n');
fprintf(output,'Global Load vector=');
fprintf(output,'\n');
for k=1:size(FG)
    fprintf(output,'%f',FG(k));
    fprintf(output,'\n');
end
fprintf(output,'\n');
fprintf(output,'\n');
fprintf(output,'Displacement at nodes:=');
fprintf(output,'\n');

for l=1:size(u)    
fprintf(output,'%f',u(l));
fprintf(output,'\n');
end

fprintf(output,'\n');
fprintf(output,'\n');
fprintf(output,'maximum stress at point A:=');
fprintf(output,'%f',stress);
fprintf(output,'\n');


end