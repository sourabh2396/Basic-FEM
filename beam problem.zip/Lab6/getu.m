function [u]=getu(NN,NDOF,FBCDoF,UBCDoF,uf,ue)
u=zeros(NN*NDOF,1);
u(UBCDoF,1)=ue;
u(FBCDoF,1)=uf;
end