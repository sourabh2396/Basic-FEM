function [le,E,I,load]= precalc(NE,CORD,MAT,SEC,ELECON,zi,UDL)
%This function calculate and stores elemental length,Youngs modulus and
%area
le=zeros(NE,1);
E=MAT(1,1);
b=SEC(1,3);
h1=SEC(1,1);
h2=SEC(1,2);
b1=UDL(1,1);
b2=UDL(1,2);
for i=1:NE
    n1 = ELECON(i,1);
    n2 = ELECON(i,2);
    le(i,1) = CORD(n2,1) - CORD(n1,1);
    h=((h2-h1)/1)*((CORD(n2,1)+CORD(n1,1))/2+zi*le(i,1)/2)+h1;
    load(i)=((b2-b1)/1)*((CORD(n2,1)+CORD(n1,1))/2+zi*le(i,1)/2)+b1;
    I(i)=b*h^3/12;
end

end