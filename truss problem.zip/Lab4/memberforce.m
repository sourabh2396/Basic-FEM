function[Fe] = memberforce(NE, ELECON, NEN, NDOF, lm, u, E, A, le, CORD)
for i = 1:1:NE
    n1 = ELECON(i,1);
    n2 = ELECON(i,2);
    x1 = CORD(n1,1);
    y1 = CORD(n1,2);
    x2 = CORD(n2,1);
    y2 = CORD(n2,2);
    l = (x2-x1)/le(i);
    m = (y2-y1)/le(i);
    T = [l, m, 0, 0; 0, 0, l, m];
    ueg = zeros(NEN*NDOF,1);
    for j = 1:1:NEN*NDOF
    ueg(j,1) = u(lm(i,j),1);
    end
    uel = T*ueg;
    Fe(i,1) = (E*A/le(i))*[-1 1]*uel;
end
end