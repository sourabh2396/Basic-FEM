function [KG,Kel1,Keg1,Kel2,Keg2]=formK(NEN,NDOF,NN,ELECON,CORD,lm,NE,le,A,E)
%%This will be generating global stiffness matrix
%initialize
KG=zeros(NN*NDOF);
NEE=NDOF*NEN;    %total dof in an element
for i=1:NE
    n1 = ELECON(i,1);
    n2 = ELECON(i,2);
    x1 = CORD(n1,1);
    y1 = CORD(n1,2);
    x2 = CORD(n2,1);
    y2 = CORD(n2,2);
    l = (x2-x1)/le(i);
    m = (y2-y1)/le(i);
    T=[l,m,0,0;0,0,l,m];
    [Ke_local,Ke_global]=formKe(A,E,le,i,T);%to get the elemental stiff mat corres to ith element
   if i==1
       Kel1=Ke_local;
       Keg1=Ke_global;
   elseif i==2
       Kel2=Ke_local;
       Keg2=Ke_global;
   end
    for j=1:NEE
        jg=lm(i,j);
        for l=1:NEE
            lg=lm(i,l);
            KG(jg,lg)=KG(jg,lg)+Ke_global(j,l);
        end
    end
end
end
            

