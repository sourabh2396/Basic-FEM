function [FG]=formF(NEN,NDOF,NN,CORD,lm,UDL,NEUDL,ELECON,NL,PLOAD,NE,le)
%%This will be generating global stiffness matrix
%initialize
FG=zeros(NN*NDOF,1);
NEE=NDOF*NEN;
%Elemental bodyforce matrix
Fe=zeros(NEN,1);
for i=1:NEUDL
    iel=UDL(i,1)
    b=UDL(i,2);
    n1 = ELECON(i,1);
    n2 = ELECON(i,2);
    x1 = CORD(n1,1);
    y1 = CORD(n1,2);
    x2 = CORD(n2,1);
    y2 = CORD(n2,2);
    l = (x2-x1)/le(iel);
    m = (y2-y1)/le(iel);
    T=[l m 0 0;0 0 l m];
    Fe_local=0.5*b*le(iel)*[1;1];
    Fe_global=(transpose(T))*Fe_local;
    for j=1:NEE
        jg=lm(iel,j);
        FG(jg)=FG(jg)+Fe_global(j)
    end
end
%Application of point load
for i = 1:NL
    ig = (PLOAD(i,1)-1)*NDOF + PLOAD(i,2);
    FG(ig,1) = PLOAD(i,3);
end
end