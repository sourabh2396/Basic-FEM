function [le,E,A]= precalc(NE,CORD,MAT,SEC,ELECON)
%This function calculate and stores elemental length,Youngs modulus and
%area
le=zeros(NE,1);
E=MAT(1,1);
A=SEC(1,1);
for i=1:NE
    n1 = ELECON(i,1);
    n2 = ELECON(i,2);
    le(i,1) = ((CORD(n1,1) - CORD(n2,1))^2 + (CORD(n1,2) - CORD(n2,2))^2)^0.5;
end

end