function [Ke_local,ke_global]=formKe(A,E,le,i,T)
%For calculating elemental stiffness for ith element.
    Ke_local=((A*E)/(le(i,1)))*[1 -1;-1 1];
    ke_global=(transpose(T))*Ke_local*T;
end