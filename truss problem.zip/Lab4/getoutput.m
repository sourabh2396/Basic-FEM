function [output]=getoutput(KG,Kel1,Kel2,Keg1,Keg2,FG,Fg1,Kg1,u,R,Fe)
output=fopen('Solutions_Lab4','wt');
fprintf(output,'Element stiffness matrix in local coordinate');
fprintf(output,'\n');
fprintf(output,'Element 1=');
fprintf(output,'\n');
for i=1:size(Kel1,1)
    for j=1:size(Kel1,2)
        fprintf(output,'%f',Kel1(i,j));
        fprintf(output,'\t');
        fprintf(output,'\t');
        
    end
    fprintf(output,'\n');
end
fprintf(output,'\n');
fprintf(output,'Element2=');
fprintf(output,'\n');
for i=1:size(Kel2,1)
    for j=1:size(Kel2,2)
        fprintf(output,'%f',Kel2(i,j));
        fprintf(output,'\t');
        fprintf(output,'\t');
        
    end
    fprintf(output,'\n');
end
fprintf(output,'\n');
fprintf(output,'Element stiffness matrix in global coordinate');
fprintf(output,'\n');
fprintf(output,'Element1=');
fprintf(output,'\n');
for i=1:size(Keg1,1)
    for j=1:size(Keg1,2)
        fprintf(output,'%f',Keg1(i,j));
        fprintf(output,'\t');
        fprintf(output,'\t');
        
    end
    fprintf(output,'\n');
end
fprintf(output,'\n');
fprintf(output,'Element2=');
fprintf(output,'\n');
for i=1:size(Keg2,1)
    for j=1:size(Keg2,2)
        fprintf(output,'%f',Keg2(i,j));
        fprintf(output,'\t');
        fprintf(output,'\t');
        
    end
    fprintf(output,'\n');
end
fprintf(output,'\n');
fprintf(output,'Global stiffness matrix=');
fprintf(output,'\n');
for i=1:size(KG,1)
    for j=1:size(KG,2)
        fprintf(output,'%f',KG(i,j));
        fprintf(output,'\t');
        fprintf(output,'\t');
        
    end
    fprintf(output,'\n');
end
fprintf(output,'\n');
fprintf(output,'Global Load vector=');
fprintf(output,'\n');
for k=1:size(FG)
    fprintf(output,'%f',FG(k));
    fprintf(output,'\n');
end
fprintf(output,'\n');

fprintf(output,'Application of Boundary cnditions:=');
fprintf(output,'\n');
fprintf(output,'Redused Stiffness matrix:=');
fprintf(output,'\n');

for l=1:size(Kg1)
    for m=1:size(Kg1)
        fprintf(output,'%f',Kg1(l,m));
        fprintf(output,'\t');
    end
     fprintf(output,'\n');
end
    
  
fprintf(output,'\n');
fprintf(output,'Redused load vector:=');
fprintf(output,'\n');

for l=1:size(Fg1)    
fprintf(output,'%f',Fg1(l));
fprintf(output,'\n');
end
fprintf(output,'\n');
fprintf(output,'Displacement at nodes:=');
fprintf(output,'\n');

for l=1:size(u)    
fprintf(output,'%f',u(l));
fprintf(output,'\n');
end

fprintf(output,'\n');
fprintf(output,'Reactions=');
fprintf(output,'\n');

for l=1:size(R)    
fprintf(output,'%f',R(l));
fprintf(output,'\n');
end

fprintf(output,'\n');
fprintf(output,'Member forces=');
fprintf(output,'\n');

for l=1:size(Fe)    
fprintf(output,'%f',Fe(l));
fprintf(output,'\n');
end
end