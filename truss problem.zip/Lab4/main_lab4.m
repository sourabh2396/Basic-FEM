close all;
clear all;
clc;
finp=fopen('input_lab4.txt','r'); % 'file name','permission'
[NN,NE,NM,NP,NIP,NDIM,NEN,NDOF,ND,NL,NEUDL,NRC,CORD,ELECON...
,BC,PLOAD,UDL,MAT,SEC]=assignscan(finp);
%precalculation for elemental area,length and E and direction cosines
[le,E,A]= precalc(NE,CORD,MAT,SEC,ELECON);
% Calculation of DOF matrix -[lm]
[lm]=dofmat(NE,NEN,NDOF,ELECON);
% Global Stiffness matrix
[KG,Kel1,Keg1,Kel2,Keg2]=formK(NEN,NDOF,NN,ELECON,CORD,lm,NE,le,A,E);
% Global load vector
[FG]=formF(NEN,NDOF,NN,CORD,lm,UDL,NEUDL,ELECON,NL,PLOAD,NE,le);
 % Application of boundary conditions
[Fg1,Kg1,ue,FBCDoF,UBCDoF] = bcapplied(ND,BC,NDOF,NN,FG,KG);
% Solving for displacements
uf = linsolve(Kg1,Fg1);
%displacements at global nodes
[u]=getu(NN,NDOF,FBCDoF,UBCDoF,uf,ue);
% Reactions
R = KG*u-FG;
%Member force
[Fe] = memberforce(NE, ELECON, NEN, NDOF, lm, u, E, A, le, CORD);

%For output
[output]=getoutput(KG,Kel1,Kel2,Keg1,Keg2,FG,Fg1,Kg1,u,R,Fe);
